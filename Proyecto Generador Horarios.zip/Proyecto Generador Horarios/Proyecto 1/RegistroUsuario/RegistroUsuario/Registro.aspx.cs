﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RegistroUsuario {
	public partial class Registro : System.Web.UI.Page {
		public Registro() {
		}
		
		protected void Page_Load(object sender, EventArgs e) {
		}

		protected void btRegistrar_Click(object sender, EventArgs e) {
			if(!txUsu.Equals("") && !txContra.Equals(""))
				lbError.Text = Conexion.registrarUsu(txUsu.Text, txContra.Text);
		}

	}
}