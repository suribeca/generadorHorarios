﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace RegistroUsuario {
	public class Conexion {
		public static SqlConnection agregarConexion() {
			SqlConnection con;

			try {
				con = new SqlConnection("Data Source=localhost;Initial Catalog=BDhorario;Integrated Security=True");
				con.Open();
			} catch(Exception ex) {
				con = null;
			}

			return con;
		}

		public static String registrarUsu(String usr, String pwd) {
			String res = "";
			SqlConnection con = agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(String.Format("SELECT count(*) FROM alumno WHERE usuario = '{0}'", usr), con);
				SqlDataReader rd = cmd.ExecuteReader();

				if(rd.Read() && rd.GetInt32(0) == 0) {
					rd.Close();
					cmd = new SqlCommand("SELECT MAX(idAl) FROM alumno", con);
					rd = cmd.ExecuteReader();
					int nuevoIdAl;

					if(rd.Read() && !rd.IsDBNull(0))
						nuevoIdAl = int.Parse(rd.GetValue(0).ToString()) + 1;
					else
						nuevoIdAl = 0;

					rd.Close();

					cmd = new SqlCommand(String.Format("INSERT INTO alumno VALUES({0}, '{1}', '{2}')", nuevoIdAl, usr, pwd), con);
					cmd.ExecuteNonQuery();

					res = "Has sido registrado";
				} else {
					res = "Este nombre de usuario ya está registrado";
				}

				rd.Close();
				con.Close();
			} catch(Exception ex) {
				res = "Error: " + ex;
			}

			return res;
		}



	}
}