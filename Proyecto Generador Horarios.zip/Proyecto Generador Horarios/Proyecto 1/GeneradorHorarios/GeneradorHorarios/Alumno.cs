﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace GeneradorHorarios {
	class Alumno {
		private String usuario { get; set; }
		private String contra { get; set; }

		public Alumno() {}
		public Alumno(string usuario) {
			this.usuario = usuario;
		}

		public Alumno(string usuario, string contra) {
			this.usuario = usuario;
			this.contra = contra;
		}

		public String buscarClave() {
			String res = "";
			SqlConnection con = Conexion.agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(String.Format("SELECT idAl FROM alumno WHERE usuario = '{0}'", usuario), con);
				SqlDataReader rd = cmd.ExecuteReader();

				if(rd.Read() && !rd.IsDBNull(0))
					res = rd.GetValue(0).ToString();

				rd.Close();
				con.Close();
			} catch(Exception ex) {
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = "Error: " + ex;
			}

			return res;
		}

		public bool baja(String pwd, String idAl) {
			bool res = false;
			SqlConnection con = Conexion.agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(String.Format("SELECT contra FROM alumno WHERE idAl = '{0}'", idAl), con);
				SqlDataReader rd = cmd.ExecuteReader();

				if(rd.Read() && !rd.IsDBNull(0) && rd.GetString(0).Equals(pwd)) {
					rd.Close();

					cmd = new SqlCommand(String.Format("DELETE FROM considera WHERE idAl = '{0}'", idAl), con);
					int query1 = cmd.ExecuteNonQuery();

					SqlCommand cmd2 = new SqlCommand(String.Format("DELETE FROM alumno WHERE usuario = '{0}'", usuario), con);
					int query2 = cmd2.ExecuteNonQuery();
					
					if(query1 != 0 && query2 != 0)
						res = true;
				}

				rd.Close();
				con.Close();
			} catch(Exception ex) {
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = "Error: " + ex;
			}

			return res;
		}

		public bool cambiarUsu(String nuevoUsu) {
			bool res = false;
			SqlConnection con = Conexion.agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(String.Format("UPDATE alumno SET usuario = '{0}' WHERE usuario = '{1}'", nuevoUsu, usuario), con);

				if(cmd.ExecuteNonQuery() != 0)
					res = true;

				con.Close();
			} catch(Exception ex) {
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = "Error: " + ex;
			}

			return res;
		}

		public bool cambiarContra(String nuevoContra) {
			bool res = false;
			SqlConnection con = Conexion.agregarConexion();

			try {
				if(Conexion.comprobarContra(usuario, contra)) {
					SqlCommand cmd = new SqlCommand(String.Format("UPDATE alumno SET contra = '{0}' WHERE usuario = '{1}'", nuevoContra, usuario), con);
					
					if(cmd.ExecuteNonQuery() != 0)
						res = true;
				}

				con.Close();
			} catch(Exception ex) {
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = "Error: " + ex;
			}

			return res;
		}

		public List<String> buscarMatRegistradas(String idAl) {
			List<String> res = new List<String>();
			SqlConnection con = Conexion.agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(String.Format("SELECT DISTINCT nombre FROM grupo, considera, materia WHERE " +
				"grupo.idGrupo = considera.idGrupo AND grupo.idMat = materia.idMat AND considera.idAl = {0}", idAl), con);
				SqlDataReader rd = cmd.ExecuteReader();

				while(rd.Read() && !rd.IsDBNull(0))
					res.Add(rd.GetValue(0).ToString());

				rd.Close();
				con.Close();
			} catch(Exception ex) {
				res = null;
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = "Error: " + ex;
			}

			return res;
		}

		//Borra los grupos anteriores de una materia para poder insertar los nuevos
		public bool borrarGrupos(String idAl, String mat) {
			bool res = false;
			SqlConnection con = Conexion.agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(String.Format("SELECT grupo.idGrupo FROM grupo, materia WHERE materia.idMat = grupo.idMat AND " +
				"nombre = '{0}'", mat), con);
				SqlDataReader rd = cmd.ExecuteReader();
				List<String> grupos = new List<String>();

				while(rd.Read() && !rd.IsDBNull(0))
					grupos.Add(rd.GetValue(0).ToString());

				rd.Close();

				while(grupos.Count > 0) {
					cmd = new SqlCommand(String.Format("DELETE FROM considera WHERE idGrupo = {0} AND idAl = {1}", grupos[0], idAl), con);
					cmd.ExecuteNonQuery();
					grupos.RemoveAt(0);
				}

				res = true;
				rd.Close();
				con.Close();
			} catch(Exception ex) {
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = "Error: " + ex;
			}

			return res;
		}

		//Une al alumno con la tabla grupo
		public bool considerarGrupo(String pref, String idGrupo, String idAl, String mat) {
			bool res = false;
			SqlConnection con = Conexion.agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(String.Format("INSERT INTO considera VALUES('{0}', {1}, {2})", pref, idGrupo, idAl), con);
				
				if(cmd.ExecuteNonQuery() > 0)
					res = true;

				con.Close();
			} catch(Exception ex) {
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = "Error: " + ex;
			}

			return res;
		}

		//Regresa una matriz con entradas [idGrupo, pref] para cada grupo de esta materia que el alumno consideró
		public String[,] gruposConsiderados(String idAl, String mat) {
			String[,] res = null;
			SqlConnection con = Conexion.agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(String.Format("SELECT count(*) FROM grupo, considera, materia WHERE " +
				"grupo.idGrupo = considera.idGrupo AND grupo.idMat = materia.idMat AND nombre = '{0}' AND considera.idAl = {1}", mat, idAl), con);
				SqlDataReader rd = cmd.ExecuteReader();

				if(rd.Read() && !rd.IsDBNull(0))
					res = new string[Int32.Parse(rd.GetValue(0).ToString()), 2];

				rd.Close();

				cmd = new SqlCommand(String.Format("SELECT grupo.idGrupo, pref FROM grupo, considera, materia WHERE " +
				"grupo.idGrupo = considera.idGrupo AND grupo.idMat = materia.idMat AND nombre = '{0}' AND considera.idAl = {1}", mat, idAl), con);
				rd = cmd.ExecuteReader();
				int i = 0;

				while(rd.Read() && !rd.IsDBNull(0)) {
					res[i, 0] = rd.GetValue(0).ToString();
					res[i, 1] = rd.GetValue(1).ToString();
					i++;
				}

				rd.Close();
				con.Close();
			} catch(Exception ex) {
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = "Error: " + ex;
			}

			return res;
		}


	}
}
