﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneradorHorarios{
	class AlgoritmosBusqueda {
		private static void swapDAI<T>(double[] arr1, List<T> arr2, int i, int j) where T : IComparable {
			double temp1 = arr1[i];
			arr1[i] = arr1[j];
			arr1[j] = temp1;

			T temp2 = arr2[i];
			arr2[i] = arr2[j];
			arr2[j] = temp2;
		}
		public static void quickSortDAI<T>(double[] arr1, List<T> arr2) where T : IComparable {
			quickSortDAI(arr1, arr2, 0, arr1.Length - 1);
		}
		private static void quickSortDAI<T>(double[] arr1, List<T> arr2, int lo, int hi) where T : IComparable {
			if(hi <= lo)
				return;

			double pivot = arr1[hi];
			int i = lo, j = hi;

			while(i < j) {
				while(i < j && pivot > arr1[i]) {
					j--;
					swapDAI(arr1, arr2, i, j);
				}

				if(i < j)
					i++;
			}

			swapDAI(arr1, arr2, i, hi);
			quickSortDAI(arr1, arr2, lo, i - 1);
			quickSortDAI(arr1, arr2, i + 1, hi);
		}
	}
}
