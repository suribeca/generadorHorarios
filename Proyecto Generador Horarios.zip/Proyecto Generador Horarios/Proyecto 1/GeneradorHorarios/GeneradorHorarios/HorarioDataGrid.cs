﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Ink;

namespace GeneradorHorarios {
	class HorarioDataGrid {
		public String materia { get; set; }
		public String profesor { get; set; }
		public String inicio { get; set; }
		public String fin { get; set; }
		public String dias { get; set; }

		public HorarioDataGrid(string materia, string profesor, string inicio, string fin, string dias) {
			this.materia = materia;
			this.profesor = profesor;
			this.inicio = inicio;
			this.fin = fin;
			this.dias = dias;
		}

		public String toString() {
			return "Mat: " + materia + " prof: " + profesor + " horaIn: " + inicio + " horaFin: " + fin + " dias: " + dias;
		}

	}

}
