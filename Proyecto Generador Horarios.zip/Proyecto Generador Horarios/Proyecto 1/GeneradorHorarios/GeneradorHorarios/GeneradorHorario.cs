﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneradorHorarios {
	class GeneradorHorario {
		//bloque: Tupla de la forma [claveMat, claveProf, horaIn, horaFin, dias, pref]
		public static List<String> generaHorarios(String[][][] bloques, int num) {
			List<String> horTerminados = new List<String>();

			//Llena una lista de códigos horarios con todas las posibilidades
			generaHorarios(bloques, horTerminados, "", 0);

			double[] puntajes = new double[horTerminados.Count];

			for(int i = 0; i < puntajes.Length; i++)
				puntajes[i] = new Horario(horTerminados[i]).calcularPuntaje();

			//Ordena la lista
			AlgoritmosBusqueda.quickSortDAI(puntajes, horTerminados);

			//Deja sólo el número de horarios que pidió el usuario
			while(horTerminados.Count > num)
				horTerminados.RemoveAt(horTerminados.Count - 1);

			return horTerminados;
		}

		public static List<String> generaHorarios(String[][][] bloques) {
			List<String> horTerminados = new List<String>();

			//Llena una lista de códigos horarios con todas las posibilidades
			generaHorarios(bloques, horTerminados, "", 0);

			//Inserta el puntaje de cada horario en un arreglo
			double[] puntajes = new double[horTerminados.Count];

			for(int i = 0; i < puntajes.Length; i++)
				puntajes[i] = new Horario(horTerminados[i]).calcularPuntaje();

			//Ordena la lista
			AlgoritmosBusqueda.quickSortDAI(puntajes, horTerminados);

			return horTerminados;
		}
		
		private static void generaHorarios(String[][][] bloques, List<String> horTerminados, String codigo, int cont) {
			if(cont >= bloques.Length) {
				horTerminados.Add(codigo);
				return;
			}

			foreach(String[] bloque in bloques[cont]) {
				Horario tempHor = new Horario(codigo);

				if(tempHor.agregarBloque(bloque[0], bloque[1], bloque[2], bloque[3], bloque[4], bloque[5]))
					generaHorarios(bloques, horTerminados, tempHor.codigo(), cont + 1);
			}
		}
	}
}
