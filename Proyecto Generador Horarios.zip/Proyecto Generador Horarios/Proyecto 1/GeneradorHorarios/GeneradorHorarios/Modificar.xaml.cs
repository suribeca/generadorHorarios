﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GeneradorHorarios {
	/// <summary>
	/// Lógica de interacción para Modificar.xaml
	/// </summary>
	public partial class Modificar : Window {
		public Modificar() {
			InitializeComponent();
		}

		private void Window_Loaded(object sender, RoutedEventArgs e) {
			txNuevoUsu.Text = App.Current.Properties["usuario"].ToString();
		}

		private void btCambiarUsu_Click(object sender, RoutedEventArgs e) {
			if(new Alumno(App.Current.Properties["usuario"].ToString()).cambiarUsu(txNuevoUsu.Text)) {
				tbError.Text = "Nombre de usuario modificado";
				App.Current.Properties["usuario"] = txNuevoUsu.Text;
			} else if(Boolean.Parse(App.Current.Properties["hayEx"].ToString())) {
				tbError.Text = App.Current.Properties["ex"].ToString();
			} else {
				tbError.Text = "No se pudó modificar el nombre de usuario";
			}

			App.Current.Properties["hayEx"] = false;
		}

		private void btCambiarContra_Click(object sender, RoutedEventArgs e) {
			if(new Alumno(App.Current.Properties["usuario"].ToString(), txContraActual.Text).cambiarContra(txContraNueva.Text))
				tbError.Text = "Contraseña modificada";
			else if(Boolean.Parse(App.Current.Properties["hayEx"].ToString()))
				tbError.Text = App.Current.Properties["ex"].ToString();
			else
				tbError.Text = "Contraseña actual incorrecta";

			App.Current.Properties["hayEx"] = false;
		}

		private void btRegresar_Click(object sender, RoutedEventArgs e) {
			new MenuPrincipal().Show();
			this.Close();
		}

		private void btElim_Click(object sender, RoutedEventArgs e) {
			new Baja().Show();
			this.Close();
		}
	}
}
