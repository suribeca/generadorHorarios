﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GeneradorHorarios {
	/// <summary>
	/// Lógica de interacción para ModificarMaterias.xaml
	/// </summary>
	public partial class ModificarMaterias : Window {
		public ModificarMaterias() {
			InitializeComponent();
			App.Current.Properties["hayEx"] = false;
			App.Current.Properties["ex"] = "";
		}

		private void Window_Loaded(object sender, RoutedEventArgs e) {
			String materia = App.Current.Properties["nombreMatSelec"].ToString();
			lbMateria.Content = materia;

			CBProfesor1.Items.Clear();
			CBProfesor1.Items.Add("Seleccione un grupo");
			CBProfesor2.Items.Clear();
			CBProfesor2.Items.Add("Seleccione un grupo");
			CBProfesor3.Items.Clear();
			CBProfesor3.Items.Add("Seleccione un grupo");
			CBProfesor4.Items.Clear();
			CBProfesor4.Items.Add("Seleccione un grupo");
			CBProfesor5.Items.Clear();
			CBProfesor5.Items.Add("Seleccione un grupo");
			CBProfesor1.SelectedIndex = 0;
			CBProfesor2.SelectedIndex = 0;
			CBProfesor3.SelectedIndex = 0;
			CBProfesor4.SelectedIndex = 0;
			CBProfesor5.SelectedIndex = 0;

			if(!Conexion.llenarComboProfesores(CBProfesor1, materia))
				lbError.Content = App.Current.Properties["ex"];

			if(!Conexion.llenarComboProfesores(CBProfesor2, materia))
				lbError.Content = App.Current.Properties["ex"];

			if(!Conexion.llenarComboProfesores(CBProfesor3, materia))
				lbError.Content = App.Current.Properties["ex"];

			if(!Conexion.llenarComboProfesores(CBProfesor4, materia))
				lbError.Content = App.Current.Properties["ex"];

			if(!Conexion.llenarComboProfesores(CBProfesor5, materia))
				lbError.Content = App.Current.Properties["ex"];

			String[,] gruposAnteriores = new Alumno().gruposConsiderados(App.Current.Properties["idAl"].ToString(), materia);

			for(int i = 0; i < gruposAnteriores.GetLength(0); i++) {
				for(int j = 1; j < CBProfesor1.Items.Count; j++) {
					if(gruposAnteriores[i, 0].Equals(CBProfesor1.Items.GetItemAt(j).ToString().Substring(6, CBProfesor1.Items.GetItemAt(j).ToString().IndexOf(":") - 6))
					&& Int32.Parse(gruposAnteriores[i, 1]) == 1) {
						CBProfesor1.SelectedIndex = j;
						break;
					}
				}
			}

			for(int i = 0; i < gruposAnteriores.GetLength(0); i++) {
				for(int j = 1; j < CBProfesor2.Items.Count; j++) {
					if(gruposAnteriores[i, 0].Equals(CBProfesor2.Items.GetItemAt(j).ToString().Substring(6, CBProfesor2.Items.GetItemAt(j).ToString().IndexOf(":") - 6))
					&& Int32.Parse(gruposAnteriores[i, 1]) == 2) {
						CBProfesor2.SelectedIndex = j;
						break;
					}
				}
			}

			for(int i = 0; i < gruposAnteriores.GetLength(0); i++) {
				for(int j = 1; j < CBProfesor3.Items.Count; j++) {
					if(gruposAnteriores[i, 0].Equals(CBProfesor3.Items.GetItemAt(j).ToString().Substring(6, CBProfesor3.Items.GetItemAt(j).ToString().IndexOf(":") - 6))
					&& Int32.Parse(gruposAnteriores[i, 1]) == 3) {
						CBProfesor3.SelectedIndex = j;
						break;
					}
				}
			}

			for(int i = 0; i < gruposAnteriores.GetLength(0); i++) {
				for(int j = 1; j < CBProfesor4.Items.Count; j++) {
					if(gruposAnteriores[i, 0].Equals(CBProfesor4.Items.GetItemAt(j).ToString().Substring(6, CBProfesor4.Items.GetItemAt(j).ToString().IndexOf(":") - 6))
					&& Int32.Parse(gruposAnteriores[i, 1]) == 4) {
						CBProfesor4.SelectedIndex = j;
						break;
					}
				}
			}

			for(int i = 0; i < gruposAnteriores.GetLength(0); i++) {
				for(int j = 1; j < CBProfesor5.Items.Count; j++) {
					if(gruposAnteriores[i, 0].Equals(CBProfesor5.Items.GetItemAt(j).ToString().Substring(6, CBProfesor5.Items.GetItemAt(j).ToString().IndexOf(":") - 6))
					&& Int32.Parse(gruposAnteriores[i, 1]) == 5) {
						CBProfesor5.SelectedIndex = j;
						break;
					}
				}
			}


		}

		private void btEliminar_Click(object sender, RoutedEventArgs e) {
			((List<string>) Application.Current.Properties["listaNombresMat"]).Remove(Application.Current.Properties["nombreMatSelec"].ToString());
			new Alumno().borrarGrupos(Application.Current.Properties["idAl"].ToString(), Application.Current.Properties["nombreMatSelec"].ToString());
			Application.Current.Properties["nombreMatSelec"] = null;
			App.Current.Properties["indexMatSelec"] = 0;
			this.Close();
		}

		private void CBProfesor1_DropDownClosed(object sender, EventArgs e) {
			if(CBProfesor1.SelectedItem != null) {
				if(CBProfesor2.SelectedItem != null && CBProfesor2.SelectedItem.Equals(CBProfesor1.SelectedItem))
					CBProfesor2.SelectedItem = "Seleccione un grupo";

				if(CBProfesor3.SelectedItem != null && CBProfesor3.SelectedItem.Equals(CBProfesor1.SelectedItem))
					CBProfesor3.SelectedItem = "Seleccione un grupo";

				if(CBProfesor4.SelectedItem != null && CBProfesor4.SelectedItem.Equals(CBProfesor1.SelectedItem))
					CBProfesor4.SelectedItem = "Seleccione un grupo";

				if(CBProfesor5.SelectedItem != null && CBProfesor5.SelectedItem.Equals(CBProfesor1.SelectedItem))
					CBProfesor5.SelectedItem = "Seleccione un grupo";
			}
		}

		private void CBProfesor2_DropDownClosed(object sender, EventArgs e) {
			if(CBProfesor2.SelectedItem != null) {
				if(CBProfesor1.SelectedItem.Equals(CBProfesor2.SelectedItem) && CBProfesor1.SelectedItem != null)
					CBProfesor1.SelectedItem = "Seleccione un grupo";

				if(CBProfesor3.SelectedItem.Equals(CBProfesor2.SelectedItem) && CBProfesor3.SelectedItem != null)
					CBProfesor3.SelectedItem = "Seleccione un grupo";

				if(CBProfesor4.SelectedItem.Equals(CBProfesor2.SelectedItem) && CBProfesor4.SelectedItem != null)
					CBProfesor4.SelectedItem = "Seleccione un grupo";

				if(CBProfesor5.SelectedItem.Equals(CBProfesor2.SelectedItem) && CBProfesor5.SelectedItem != null)
					CBProfesor5.SelectedItem = "Seleccione un grupo";
			}
		}

		private void CBProfesor3_DropDownClosed(object sender, EventArgs e) {
			if(CBProfesor3.SelectedItem != null) {
				if(CBProfesor1.SelectedItem.Equals(CBProfesor3.SelectedItem) && CBProfesor1.SelectedItem != null)
					CBProfesor1.SelectedItem = "Seleccione un grupo";

				if(CBProfesor2.SelectedItem.Equals(CBProfesor3.SelectedItem) && CBProfesor2.SelectedItem != null)
					CBProfesor2.SelectedItem = "Seleccione un grupo";

				if(CBProfesor4.SelectedItem.Equals(CBProfesor3.SelectedItem) && CBProfesor4.SelectedItem != null)
					CBProfesor4.SelectedItem = "Seleccione un grupo";

				if(CBProfesor5.SelectedItem.Equals(CBProfesor3.SelectedItem) && CBProfesor5.SelectedItem != null)
					CBProfesor5.SelectedItem = "Seleccione un grupo";
			}
		}

		private void CBProfesor4_DropDownClosed(object sender, EventArgs e) {
			if(CBProfesor4.SelectedItem != null) {
				if(CBProfesor1.SelectedItem.Equals(CBProfesor4.SelectedItem) && CBProfesor1.SelectedItem != null)
					CBProfesor1.SelectedItem = "Seleccione un grupo";

				if(CBProfesor3.SelectedItem.Equals(CBProfesor4.SelectedItem) && CBProfesor3.SelectedItem != null)
					CBProfesor3.SelectedItem = "Seleccione un grupo";

				if(CBProfesor2.SelectedItem.Equals(CBProfesor4.SelectedItem) && CBProfesor2.SelectedItem != null)
					CBProfesor2.SelectedItem = "Seleccione un grupo";

				if(CBProfesor5.SelectedItem.Equals(CBProfesor4.SelectedItem) && CBProfesor5.SelectedItem != null)
					CBProfesor5.SelectedItem = "Seleccione un grupo";
			}
		}

		private void CBProfesor5_DropDownClosed(object sender, EventArgs e) {
			if(CBProfesor5.SelectedItem != null) {
				if(CBProfesor1.SelectedItem.Equals(CBProfesor5.SelectedItem) && CBProfesor1.SelectedItem != null)
					CBProfesor1.SelectedItem = "Seleccione un grupo";

				if(CBProfesor3.SelectedItem.Equals(CBProfesor5.SelectedItem) && CBProfesor3.SelectedItem != null)
					CBProfesor3.SelectedItem = "Seleccione un grupo";

				if(CBProfesor4.SelectedItem.Equals(CBProfesor5.SelectedItem) && CBProfesor4.SelectedItem != null)
					CBProfesor4.SelectedItem = "Seleccione un grupo";

				if(CBProfesor2.SelectedItem.Equals(CBProfesor5.SelectedItem) && CBProfesor2.SelectedItem != null)
					CBProfesor2.SelectedItem = "Seleccione un grupo";
			}
		}

		private void btConfirmar_Click(object sender, RoutedEventArgs e) {
			List<String> listaGrupos = new List<String>();
			String pref, idGrupo, idAl = App.Current.Properties["idAl"].ToString();

			//Borra los grupos anteriores de esta materia que el alumno haya considerado
			if(!new Alumno().borrarGrupos(idAl, App.Current.Properties["nombreMatSelec"].ToString()) && !bool.Parse(App.Current.Properties["hayEx"].ToString()))
				MessageBox.Show("Error al agregar grupos");
			else if(bool.Parse(App.Current.Properties["hayEx"].ToString()))
				MessageBox.Show(App.Current.Properties["ex"].ToString());

			//Inserta los nuevos grupos de esta materia
			if(CBProfesor1.SelectedIndex != 0) {
				pref = "1";
				idGrupo = CBProfesor1.SelectedItem.ToString().Substring(6, CBProfesor1.SelectedItem.ToString().IndexOf(":") - 6);
				listaGrupos.Add(idGrupo);

				if(new Alumno().considerarGrupo(pref, idGrupo, idAl, App.Current.Properties["nombreMatSelec"].ToString()))
					lbError.Content = "";
				else
					MessageBox.Show(App.Current.Properties["ex"].ToString());
			}
			if(CBProfesor2.SelectedIndex != 0) {
				pref = "2";
				idGrupo = CBProfesor2.SelectedItem.ToString().Substring(6, CBProfesor2.SelectedItem.ToString().IndexOf(":") - 6);
				listaGrupos.Add(idGrupo);

				if(new Alumno().considerarGrupo(pref, idGrupo, idAl, App.Current.Properties["nombreMatSelec"].ToString()))
					lbError.Content = "";
				else
					MessageBox.Show(App.Current.Properties["ex"].ToString());
			}
			if(CBProfesor3.SelectedIndex != 0) {
				pref = "3";
				idGrupo = CBProfesor3.SelectedItem.ToString().Substring(6, CBProfesor3.SelectedItem.ToString().IndexOf(":") - 6);
				listaGrupos.Add(idGrupo);

				if(new Alumno().considerarGrupo(pref, idGrupo, idAl, App.Current.Properties["nombreMatSelec"].ToString()))
					lbError.Content = "";
				else
					MessageBox.Show(App.Current.Properties["ex"].ToString());
			}
			if(CBProfesor4.SelectedIndex != 0) {
				pref = "4";
				idGrupo = CBProfesor4.SelectedItem.ToString().Substring(6, CBProfesor4.SelectedItem.ToString().IndexOf(":") - 6);
				listaGrupos.Add(idGrupo);

				if(new Alumno().considerarGrupo(pref, idGrupo, idAl, App.Current.Properties["nombreMatSelec"].ToString()))
					lbError.Content = "";
				else
					MessageBox.Show(App.Current.Properties["ex"].ToString());
			}
			if(CBProfesor5.SelectedIndex != 0) {
				pref = "5";
				idGrupo = CBProfesor5.SelectedItem.ToString().Substring(6, CBProfesor5.SelectedItem.ToString().IndexOf(":") - 6);
				listaGrupos.Add(idGrupo);

				if(new Alumno().considerarGrupo(pref, idGrupo, idAl, App.Current.Properties["nombreMatSelec"].ToString()))
					lbError.Content = "";
				else
					MessageBox.Show(App.Current.Properties["ex"].ToString());
			}

			/*((String[][][])App.Current.Properties["bloques"])[(int)App.Current.Properties["indexMatSelec"]] = new String[listaGrupos.Count][];

			for(int i = 0; i < listaGrupos.Count; i++)
				((String[][][])App.Current.Properties["bloques"])[(int)App.Current.Properties["indexMatSelec"]][i] = Conexion.bloqueGrupo(listaGrupos[i], idAl);*/

			//new MenuPrincipal().Show();
			this.Close();
		}

		private void btRegresar_Click(object sender, RoutedEventArgs e) {
			//new MenuPrincipal().Show();
			this.Close();
		}
		
	}

}
