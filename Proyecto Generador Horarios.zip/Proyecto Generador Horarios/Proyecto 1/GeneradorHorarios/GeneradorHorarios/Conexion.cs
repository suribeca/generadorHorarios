﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace GeneradorHorarios {
	class Conexion {
		public static SqlConnection agregarConexion() {
			SqlConnection cnn;

			try {
				cnn = new SqlConnection("Data Source=localhost;Initial Catalog=BDhorario;Integrated Security=True");
				cnn.Open();
			} catch(Exception ex) {
				cnn = null;
				MessageBox.Show("No fue posible conectarse a la base de datos");
			}

			return cnn;
		}

		public static bool comprobarContra(String usr, String pwd) {
			bool res = false;
			SqlConnection con = agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(String.Format("SELECT contra FROM alumno WHERE usuario = '{0}'", usr), con);
				SqlDataReader rd = cmd.ExecuteReader();

				if(rd.Read() && !rd.IsDBNull(0) && rd.GetString(0).Equals(pwd))
					res = true;

				rd.Close();
				con.Close();
			} catch(Exception ex) {
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = "Error: " + ex;
			}

			return res;
		}

		public static bool llenarCombo(ComboBox cb, String query) {
			bool res = false;
			SqlConnection con = agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(query, con);
				SqlDataReader rd = cmd.ExecuteReader();

				while(rd.Read() && !rd.IsDBNull(0)) {
					cb.Items.Add(rd.GetValue(0));
					res = true;
				}

				cb.SelectedIndex = 0;

				rd.Close();
				con.Close();
			} catch(Exception ex) {
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = "Error: " + ex;
			}

			return res;
		}

		//Regresa el id de una materia dado su nombre
		public static String buscarIdMateria(String materia) {
			String res = "";
			SqlConnection con = agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(String.Format("SELECT idMat FROM materia WHERE nombre = '{0}'", materia), con);
				SqlDataReader rd = cmd.ExecuteReader();

				if(rd.Read() && !rd.IsDBNull(0))
					res = rd.GetValue(0).ToString();

				rd.Close();
				con.Close();
			} catch(Exception ex) {
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = ex;
			}

			return res;
		}

		//Regresa las posibles opciones para una materia dada en una lista: [idGrupo, idMat, idProf, horaIn, horaFin, dias]
		public static String[,] buscarOpciones(String materia) {
			String[,] res = null;
			String idMat = Conexion.buscarIdMateria(materia);
			SqlConnection con = agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(String.Format("SELECT count(*) FROM profesor, grupo WHERE profesor.idProf = grupo.IdProf AND " +
				"grupo.idMat = '{0}'", idMat), con);
				SqlDataReader rd = cmd.ExecuteReader();

				if(rd.Read() && !rd.IsDBNull(0))
					res = new string[Int32.Parse(rd.GetValue(0).ToString()), 6];

				rd.Close();

				cmd = new SqlCommand(String.Format("SELECT idGrupo, profesor.idProf, horaInicio, horaFin, dias " +
				"FROM profesor, grupo WHERE profesor.idProf = grupo.IdProf AND grupo.idMat = '{0}'", idMat), con);
				rd = cmd.ExecuteReader();

				int i = 0;

				while(rd.Read()) {
					String horaIn = Conexion.convertirHora(Int32.Parse(rd.GetValue(1).ToString()));
					String horaFin = Conexion.convertirHora(Int32.Parse(rd.GetValue(2).ToString()));
					String dias = Conexion.convertirDias(rd.GetValue(3).ToString());
					res[i, 0] = rd.GetValue(0).ToString();
					res[i, 1] = idMat;
					res[i, 2] = rd.GetValue(1).ToString();
					res[i, 3] = rd.GetValue(2).ToString();
					res[i, 4] = rd.GetValue(3).ToString();
					res[i, 5] = rd.GetValue(4).ToString();

					i++;
				}

				rd.Close();
				con.Close();
			} catch(Exception ex) {
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = ex;
			}

			return res;
		}

		//Regresa el bloque asociado a un grupo: [idMat, idProf, horaIn, horaFin, dias, pref]
		public static String[] bloqueGrupo(String idGrupo, String idAl) {
			String[] res = new string[6];
			SqlConnection con = agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(String.Format("SELECT idMat, idProf, horaInicio, horaFin, dias, pref " +
				"FROM grupo, considera WHERE grupo.IdGrupo = considera.idGrupo AND grupo.idGrupo = '{0}'", idGrupo), con);
				SqlDataReader rd = cmd.ExecuteReader();

				if(rd.Read() && !rd.IsDBNull(0)) {
					String horaIn = Conexion.convertirHora(Int32.Parse(rd.GetValue(1).ToString()));
					String horaFin = Conexion.convertirHora(Int32.Parse(rd.GetValue(2).ToString()));
					String dias = Conexion.convertirDias(rd.GetValue(4).ToString());
					
					res[0] = rd.GetValue(0).ToString();
					res[1] = rd.GetValue(1).ToString();
					res[2] = horaIn;
					res[3] = horaFin;
					res[4] = dias;
					res[5] = rd.GetValue(5).ToString();
				}

				rd.Close();
				con.Close();
			} catch(Exception ex) {
				res = null;
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = ex;
			}

			return res;
		}

		public static bool llenarComboProfesores(ComboBox cb, String materia) {
			bool res = false;
			String idMat = Conexion.buscarIdMateria(materia);
			SqlConnection con = agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(String.Format("SELECT idGrupo, nombre, horaInicio, horaFin, dias " +
				"FROM profesor, grupo WHERE profesor.idProf = grupo.IdProf AND idMat = '{0}'", idMat), con);
				SqlDataReader rd = cmd.ExecuteReader();

				while(rd.Read()) {
					StringBuilder opcion = new StringBuilder();

					String horaIn = convertirHora(Int32.Parse(rd.GetValue(2).ToString()));
					String horaFin = convertirHora(Int32.Parse(rd.GetValue(3).ToString()));
					String dias = convertirDias(rd.GetValue(4).ToString());

					opcion.Append("Grupo " + rd.GetValue(0).ToString() + ": ").Append(rd.GetString(1)).Append(", ").Append(horaIn).Append("-").Append(horaFin).Append(", ").Append(dias);
					cb.Items.Add(opcion.ToString());
					res = true;
				}
				
				rd.Close();
				con.Close();
			} catch(Exception ex) {
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = ex;
			}

			return res;
		}

		private static String convertirHora(int hora) {
			String horModificada = (hora / 2 + 7) + "";

			if((2 * (hora / 2.0 + 7.0)) % 2 == 0)
				horModificada += ":00";
			else
				horModificada += ":30";

			return horModificada;
		}

		private static String convertirDias(String dias) {
			String[] nombre = {"Lu", "Ma", "Mi", "Ju", "Vi"};
			String diasMod = "";


			for(int i = 0; i < 5; i++) {
				if(dias[i].Equals('1'))
					diasMod += nombre[i];
				else
					diasMod += "-";
			}

			return diasMod;
		}

		//Regresa todos los bloques asociados a un alumno
		public static String[][][] buscarTodosBloques(String idAl) {
			String[][][] res = null;
			SqlConnection con = agregarConexion();

			try {
				SqlCommand cmd = new SqlCommand(String.Format("SELECT DISTINCT materia.idMat FROM materia, grupo, considera WHERE " +
				"materia.idMat = grupo.idMat AND grupo.idGrupo = considera.idGrupo AND idAl = {0}", idAl), con);
				SqlDataReader rd = cmd.ExecuteReader();
				List<String> listaMat = new List<string>();

				while(rd.Read() && !rd.IsDBNull(0))
					listaMat.Add(rd.GetValue(0).ToString());

				rd.Close();

				res = new string[listaMat.Count][][];

				for(int i = 0; i < listaMat.Count; i++) {
					cmd = new SqlCommand(String.Format("SELECT count(*) as c FROM grupo, considera WHERE " +
					"grupo.idGrupo = considera.idGrupo AND idMat = '{0}' AND idAl = {1}", listaMat[i], idAl), con);
					rd = cmd.ExecuteReader();

					if(rd.Read() && !rd.IsDBNull(0))
						res[i] = new String[Int32.Parse(rd.GetValue(0).ToString())][];

					rd.Close();

					cmd = new SqlCommand(String.Format("SELECT idProf, horaInicio, horaFin, dias, pref FROM grupo, considera WHERE " +
					"grupo.idGrupo = considera.idGrupo AND idMat = '{0}' AND idAl = {1}", listaMat[i], idAl), con);
					rd = cmd.ExecuteReader();

					int j = 0;

					while(rd.Read() && !rd.IsDBNull(0)) {
						res[i][j] = new string[6];

						res[i][j][0] = listaMat[i];
						res[i][j][1] = rd.GetValue(0).ToString();
						res[i][j][2] = rd.GetValue(1).ToString();
						res[i][j][3] = rd.GetValue(2).ToString();
						res[i][j][4] = rd.GetValue(3).ToString();
						res[i][j][5] = rd.GetValue(4).ToString();

						j++;
					}

					rd.Close();
				}

				con.Close();
			} catch(Exception ex) {
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = "Error: " + ex;
			}

			return res;
		}

		public static List<HorarioDataGrid> llenarDataGrid(DataGrid dg, String codigoHor) {
			List<HorarioDataGrid> res = new List<HorarioDataGrid>();
			SqlConnection con = agregarConexion();

			try {
				String[,] bloques = new Horario(codigoHor).getTuplas();

				for(int i = 0; i < bloques.GetLength(0); i++) {
					String idMat = bloques[i, 0];
					String idProf = bloques[i, 1];
					String nombreMat = "";

					SqlCommand cmd = new SqlCommand(String.Format("SELECT nombre FROM materia WHERE idMat = '{0}'", idMat), con);
					SqlDataReader rd = cmd.ExecuteReader();

					if(rd.Read() && !rd.IsDBNull(0))
						nombreMat = rd.GetValue(0).ToString();

					rd.Close();

					cmd = new SqlCommand(String.Format("SELECT nombre FROM profesor WHERE idProf = '{0}'", idProf), con);
					rd = cmd.ExecuteReader();

					if(rd.Read() && !rd.IsDBNull(0))
						res.Add(new HorarioDataGrid(nombreMat, rd.GetValue(0).ToString(), convertirHora(Int32.Parse(bloques[i, 2])),
						convertirHora(Int32.Parse(bloques[i, 3])), convertirDias(bloques[i, 4])));

					rd.Close();
				}

				con.Close();
			} catch(Exception ex) {
				res = null;
				App.Current.Properties["hayEx"] = true;
				App.Current.Properties["ex"] = "Error: " + ex;
			}

			return res;
		}

	}
}
