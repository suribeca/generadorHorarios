﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GeneradorHorarios {
	/// <summary>
	/// Lógica de interacción para MenuPrincipal.xaml
	/// </summary>
	public partial class MenuPrincipal : Window {
		public MenuPrincipal() {
			InitializeComponent();
			App.Current.Properties["listaNombresMat"] = new List<String>();
			App.Current.Properties["nombreMatSelec"] = null;
			App.Current.Properties["indexMatSelec"] = 0;
			App.Current.Properties["bloques"] = null;
			App.Current.Properties["horTerminados"] = null;
			App.Current.Properties["horIndex"] = 0;
			App.Current.Properties["numHor"] = 0; 
			App.Current.Properties["hayEx"] = false;
			App.Current.Properties["ex"] = "";
		}

		//LLenado de combo boxes e inicialización de sesiones
		private void Window_Loaded(object sender, RoutedEventArgs e) {
			lbSaludo.Content = lbSaludo.Content.ToString().Substring(0, 12) + App.Current.Properties["usuario"].ToString();

			//Número de horarios deseado
			cbOpciones.Items.Clear();

			cbOpciones.Items.Add(1);
			cbOpciones.Items.Add(5);
			cbOpciones.Items.Add(10);
			cbOpciones.Items.Add(20);
			cbOpciones.Items.Add(50);

			cbOpciones.SelectedIndex = 0;

			//Combo con opciones de materias
			cbRegistrarMaterias.Items.Clear();
			cbRegistrarMaterias.Items.Add("Seleccione una materia");

			if(!Conexion.llenarCombo(cbRegistrarMaterias, "SELECT nombre FROM materia"))
				tbOutputs.Text = "Error al buscar las materias disponibles";

			cbRegistrarMaterias.SelectedIndex = 0;

			//Combo con materias seleccionadas
			cbModificarMateria.Items.Clear();
			cbModificarMateria.Items.Add("Seleccione una materia");

			App.Current.Properties["listaNombresMat"] = new Alumno().buscarMatRegistradas(App.Current.Properties["idAl"].ToString());

			for(int i = 0; App.Current.Properties["listaNombresMat"] != null && i < ((List<String>) App.Current.Properties["listaNombresMat"]).Count; i++)
				cbModificarMateria.Items.Add(((List<String>) App.Current.Properties["listaNombresMat"])[i].ToString());

			cbModificarMateria.SelectedIndex = 0;
			tbMateriasRegistradas.Text = String.Format("Tienes {0} materias registradas de un máximo de 10", cbModificarMateria.Items.Count - 1);

			App.Current.Properties["bloques"] = Conexion.buscarTodosBloques(App.Current.Properties["idAl"].ToString());

			if(bool.Parse(App.Current.Properties["hayEx"].ToString()))
				System.Diagnostics.Debug.WriteLine(App.Current.Properties["ex"].ToString());
		}

		//Actualizaciones a partir de que se intenta registrar una materia. Si se puede, se quita dicha materia de la combo box de registro y se añade a la combo box de modificar
		private void btRegistrarMateria_Click(object sender, RoutedEventArgs e) {
			if(cbRegistrarMaterias.SelectedIndex > 0) {
				if(cbModificarMateria.Items.Count <= 10) {
					if(!cbModificarMateria.Items.Contains(cbRegistrarMaterias.SelectedItem)) {
						cbModificarMateria.Items.Add(cbRegistrarMaterias.Text);
						tbMateriasRegistradas.Text = String.Format("Tienes {0} materias registradas de un máximo de 10", cbModificarMateria.Items.Count - 1);

						((List<string>)App.Current.Properties["listaNombresMat"]).Add(cbRegistrarMaterias.SelectedItem.ToString());
						cbRegistrarMaterias.SelectedIndex = 0;

						tbOutputs.Text = "Materia registrada";
					} else {
						tbOutputs.Text = "Materia ya registrada, por favor seleccione otra";
					}
				} else {
					tbOutputs.Text = "Ya se ha elegido el número máximo de materias permitidas";
				}
			}
		}

		private void btCambiarUserData_Click(object sender, RoutedEventArgs e) {
			new Modificar().Show();
			this.Close();
		}

		//Abre la ventana para seleccionar grupos
		private void btModificarMateria_Click(object sender, RoutedEventArgs e) {
			if(cbModificarMateria.SelectedIndex > 0) {
				App.Current.Properties["nombreMatSelec"] = cbModificarMateria.SelectedItem.ToString();
				App.Current.Properties["indexMatSelec"] = cbModificarMateria.SelectedIndex;
				new ModificarMaterias().ShowDialog();

				cbModificarMateria.Items.Clear();
				cbModificarMateria.Items.Add("Seleccione una materia");

				for(int i = 0; App.Current.Properties["listaNombresMat"] != null && i < ((List<String>)App.Current.Properties["listaNombresMat"]).Count; i++)
					cbModificarMateria.Items.Add(((List<String>)App.Current.Properties["listaNombresMat"])[i].ToString());

				cbModificarMateria.SelectedIndex = 0;
				tbMateriasRegistradas.Text = String.Format("Tienes {0} materias registradas de un máximo de 10", cbModificarMateria.Items.Count - 1);
			}
		}

		//Genera el número de horarios deseados y llena la tabla
		private void btGenerarH_Click(object sender, RoutedEventArgs e) {
			try {
				App.Current.Properties["bloques"] = Conexion.buscarTodosBloques(App.Current.Properties["idAl"].ToString());
				App.Current.Properties["horTerminados"] = GeneradorHorario.generaHorarios((String[][][]) App.Current.Properties["bloques"], Int32.Parse(cbOpciones.SelectedItem.ToString()));

				if(((List<String>) App.Current.Properties["horTerminados"]).Count > 0) {
					App.Current.Properties["numHor"] = Math.Min(((List<String>)App.Current.Properties["horTerminados"]).Count, Int32.Parse(cbOpciones.SelectedItem.ToString()));
					
					App.Current.Properties["horIndex"] = 0;
					lbHorarios.Content = String.Format("{0} de {1}", (int) App.Current.Properties["horIndex"] + 1, App.Current.Properties["numHor"]);
					dgHorario.ItemsSource = Conexion.llenarDataGrid(dgHorario, ((List<String>) App.Current.Properties["horTerminados"])[0]);
				} else {
					App.Current.Properties["horIndex"] = 0;
					dgHorario.ItemsSource = "No hay horarios posibles";
				}
			} catch(Exception ex) {
				MessageBox.Show(ex + "");
			}
		}

		//Muestra el horario anterior
		private void btAtras_Click(object sender, RoutedEventArgs e) {
			if(App.Current.Properties["horTerminados"] != null && (int) App.Current.Properties["horIndex"] > 0) {
				App.Current.Properties["horIndex"] = ((int) App.Current.Properties["horIndex"]) - 1;
				lbHorarios.Content = String.Format("{0} de {1}", (int) App.Current.Properties["horIndex"] + 1, App.Current.Properties["numHor"]);
				dgHorario.ItemsSource = Conexion.llenarDataGrid(dgHorario, ((List<String>) App.Current.Properties["horTerminados"])[(int) App.Current.Properties["horIndex"]]);
			}
		}

		//Muestra el horario siguiente
		private void btAdelante_Click(object sender, RoutedEventArgs e) {
			if(App.Current.Properties["horTerminados"] != null && (int) App.Current.Properties["horIndex"] < (int) App.Current.Properties["numHor"] - 1) {
				App.Current.Properties["horIndex"] = ((int) App.Current.Properties["horIndex"]) + 1;
				lbHorarios.Content = String.Format("{0} de {1}", (int) App.Current.Properties["horIndex"] + 1, App.Current.Properties["numHor"]);
				dgHorario.ItemsSource = Conexion.llenarDataGrid(dgHorario, ((List<String>) App.Current.Properties["horTerminados"])[(int) App.Current.Properties["horIndex"]]);
			}
		}

		//Termina la ejecución del programa
		private void btFinalizar_Click(object sender, RoutedEventArgs e) {
			new MainWindow().Show();
			this.Close();
		}

	}
}
