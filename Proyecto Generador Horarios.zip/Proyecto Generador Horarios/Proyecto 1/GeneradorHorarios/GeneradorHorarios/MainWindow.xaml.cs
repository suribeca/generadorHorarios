﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GeneradorHorarios {
	/// <summary>
	/// Lógica de interacción para Ingreso.xaml
	/// </summary>
	/// 
	public partial class MainWindow : Window {
		public MainWindow() {
			InitializeComponent();
			App.Current.Properties["usuario"] = null;
			App.Current.Properties["idAl"] = null;
			App.Current.Properties["hayEx"] = false;
			App.Current.Properties["ex"] = "";
		}

		private void Window_Loaded(object sender, RoutedEventArgs e) {
			txUsu.Text = "";
			txContra.Text = "";
			txUsu.Focusable = true;
			Keyboard.Focus(txUsu);
		}

		private void btIngresar_Click(object sender, RoutedEventArgs e) {
			String idAl = new Alumno(txUsu.Text).buscarClave();

			if(Conexion.comprobarContra(txUsu.Text, txContra.Text) && idAl.Length > 0) {
				App.Current.Properties["usuario"] = txUsu.Text;
				App.Current.Properties["idAl"] = idAl;

				new MenuPrincipal().Show();
				this.Close();
			} else if(Boolean.Parse(App.Current.Properties["hayEx"].ToString())) {
				lbError.Content = App.Current.Properties["ex"];
			} else {
				lbError.Content = "Tu usuario o contraseña son incorrectos";
			}

			App.Current.Properties["hayEx"] = false;
		}

	}
}
