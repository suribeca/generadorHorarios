﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneradorHorarios {
	class Horario {
		private String[,] bloques; //Tuplas de la forma [claveMat, claveProf, horaIn, horaFin, dias, pref]; hay un bloque por materia
		private int[,] tabla; //Guarda qué lugares ya están ocupados
		private int contMat;
		private const int MAX_MAT = 10;

		public Horario() {
			bloques = new String[MAX_MAT, 6];
			tabla = new int[5, 30];
			contMat = 0;

			for(int i = 0; i < tabla.GetLength(0); i++)
				for(int j = 0; j < tabla.GetLength(1); j++)
					tabla[i, j] = 0;
		}

		public Horario(String codigo) : this() {
			for(int i = 0; i < codigo.Length; i += 17, contMat++) {
				bloques[contMat, 0] = codigo.Substring(i, 3);
				bloques[contMat, 1] = codigo.Substring(i + 3, 3);
				bloques[contMat, 2] = codigo.Substring(i + 6, 2);
				bloques[contMat, 3] = codigo.Substring(i + 8, 2);
				bloques[contMat, 4] = codigo.Substring(i + 10, 5);
				bloques[contMat, 5] = codigo.Substring(i + 15, 1);
			}

			for(int i = 0; i < contMat; i++)
				for(int j = 0; j < 5; j++)
					for(int k = Int32.Parse(bloques[i, 2]); k < Int32.Parse(bloques[i, 3]); k++)
						if(bloques[i, 4][j] == '1')
							tabla[j, k] = 1;
		}

		public String[,] getTuplas() {
			String[,] tuplas = new string[contMat, 6];

			for(int i = 0; i < contMat; i++)
				for(int j = 0; j < 6; j++)
					tuplas[i, j] = bloques[i, j];
			
			return tuplas;
		}

		//Formato hora: 24h. Restar 7 y multiplicar por 2 antes de pasar. ej. 7:30 a.m. -> 7.5 -> 1, 4:00 p.m. -> 16 -> 18
		//Formato día: número de 5 dígitos. 1 si se da en ese día, 0 de lo contrario
		//ej. lun, mar, vie -> 11001
		public bool agregarBloque(String claveMat, String claveProf, String horaIn, String horaFin, String dias, String pref) {
			//Valida el formato de los datos
			if(claveMat == null || claveProf == null || horaIn == null || horaFin == null || dias == null || pref == null ||
				claveMat.Length != 3 || claveProf.Length != 3 || horaIn.Length != 2 || horaFin.Length != 2 || dias.Length != 5 || pref.Length != 1)
				return false;

			//Valida que no se haya excedido el máximo de materias y que los datos tengan sentido
			if(contMat >= MAX_MAT || Int32.Parse(horaFin) <= Int32.Parse(horaIn) || dias.Equals("00000"))
				return false;

			//Valida que la materia no esté registrada aún
			for(int i = 0; i < contMat; i++)
				if(bloques[i, 0].Equals(claveMat))
					return false;

			//Valida que no haya empalmes
			for(int i = 0; i < 5; i++)
				for(int j = Int32.Parse(horaIn); j < Int32.Parse(horaFin); j++)
					if(dias[i] == '1' && tabla[i, j] == 1)
						return false;

			//--------------------------Fin validaciones-----------------------------------

			//Marca los lugares que ocupa esta tupla
			for(int i = 0; i < 5; i++)
				for(int j = Int32.Parse(horaIn); j < Int32.Parse(horaFin); j++)
					if(dias[i] == '1')
						tabla[i, j] = 1;

			//Registra la tupla
			bloques[contMat, 0] = claveMat;
			bloques[contMat, 1] = claveProf;
			bloques[contMat, 2] = horaIn;
			bloques[contMat, 3] = horaFin;
			bloques[contMat, 4] = dias;
			bloques[contMat, 5] = pref;
			contMat++;

			return true;
		}

		public double calcularPuntaje() {
			double puntaje = 0;

			for(int i = 0; i < contMat; i++)
				puntaje += 11 - Int32.Parse(bloques[i, 5]);

			return puntaje;
		}

		public String codigo() {
			String code = "";

			for(int i = 0; i < contMat; i++) {
				for(int j = 0; j < bloques.GetLength(1); j++)
					code += bloques[i, j];

				code += " ";
			}

			return code;
		}
	}
}
