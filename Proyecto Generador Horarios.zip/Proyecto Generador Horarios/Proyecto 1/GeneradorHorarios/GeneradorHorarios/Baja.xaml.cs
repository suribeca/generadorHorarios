﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GeneradorHorarios {
	/// <summary>
	/// Lógica de interacción para Baja.xaml
	/// </summary>
	public partial class Baja : Window {
		public Baja() {
			InitializeComponent();
		}

		private void btElim_Click(object sender, RoutedEventArgs e) {
			if(new Alumno(App.Current.Properties["usuario"].ToString()).baja(txContra.Text, App.Current.Properties["idAl"].ToString())) {
				MessageBox.Show("Tu cuenta ha sido eliminada. Redirigiendo...");
				System.Threading.Thread.Sleep(2000);
				new MainWindow().Show();
				this.Close();
			} else if(Boolean.Parse(App.Current.Properties["hayEx"].ToString())) {
				lbError.Content = App.Current.Properties["ex"];
			} else {
				lbError.Content = "Tu contraseña es incorrecta";
			}

			App.Current.Properties["hayEx"] = false;
		}

		private void btRegresar_Click(object sender, RoutedEventArgs e) {
			new Modificar().Show();
			this.Close();
		}
	}
}
